module.exports = {
  tokens: "8003564302:AAHXuoVjeqUI-9uxZzvDoPVVAVQ_vYMjXDM",  // Ubah Jadi Token Bot Mu !!!
  owner: "8136310152", // Ubah Jadi Id Mu !!!
  port: "3005", // Ubah Jadi Port Panel Mu !!!
  ipvps: "152.42.162.115" // Ubah Jadi Ip Vps Mu !!!
};